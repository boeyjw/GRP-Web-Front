var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
 
var util = require('util');
var assert = require('assert');


 /* GET home page. */
// Defines the root route. router.get receives a path and a function
// The req object represents the HTTP request and contains
// the query string, parameters, body, header
// The res object is the response Express sends when it receives
// a request
// render says to use the views/index.jade file for the layout
// and to set the value for title to 'Express'
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
 
router.get('/thelist', function(req, res){
 
  // Get a Mongo client to work with the Mongo server
  var MongoClient = mongodb.MongoClient;
 
  // Define where the MongoDB server is
  var url = 'mongodb://localhost:27017/test';
 
  // Connect to the server
  MongoClient.connect(url, function (err, db) {
  if (err) {
    console.log('Unable to connect to the Server', err);
  } else {
    // We are connected
    console.log('Connection established to', url);
 
    // Get the documents collection
    var collection = db.collection('cffplants');
 
    // Find all students
    collection.find({"canonicalName": "Marchantiophyta"}).toArray(function (err, result) {
      if (err) {
        res.send(err);
      } else if (result.length) {
        res.render('studentlist',{
 
          // Pass the returned database documents to Jade
          "studentlist" : result
        });
      } else {
        res.send('No documents found');
      }
      //Close connection
      db.close();
    });
  }
  });
});
 


router.get("/search", function(req,res){
  res.sendfile("./views/search.html", {title: "search"});
});

router.post("/search", function(req, res){
 
  var MongoClient = mongodb.MongoClient;

  var url = 'mongodb://localhost:27017/test';

  MongoClient.connect(url, function(err, db) {
    if(err){
      console.log("No connection", err);
    }else{
    console.log("Connected");

  db.ensureIndex("cffplants", {document: "text"}, function(err, indexname){
    assert.equal(null,err);
  });



  db.collection('cffplants').find({
    "$text":{
      "$search": "req.body.query"
    }
  },
  {
    "scientificName": 1,
    "canonicalName": 1,
    "taxonRank":1,
    "Rank":1,
    "parentTaxId":1,
    _id:0
  }).toArray(function(err,items){
   if (err) {
        res.send(err);
      } else if (result.length) {
        res.render('studentlist',{
 
          // Pass the returned database documents to Jade
          "studentlist" : result
        });
      } else {
        res.send('No documents found');
      }
      //Close connection
      db.close();
  });

  }
  });
});

function pagelist(items){
  result = "<html><body><ul>";
  items.forEach (function(item) {
    itemstring = "<li>"+ item.scientificName + "<ul><li>" + item.canonicalName + "</li><li>" + item.multimedia.identifier + "</li><li>" + item.taxonRank + "</li><li>" + item.rank + "</li><li>" + item.distribution.country + "</li><li>" + item.parentTaxID + "</li></ul><li>";
    result = result + itemstring;
  });
  result = result + "</ul></body></html>";
  return result;
}
 
module.exports = router;
