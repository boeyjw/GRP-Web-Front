/*
var MongoClient = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/test'

MongoClient.connect(url, function(err, db){
	if(err){
		console.log('unable to connect to the mongoDB server. Error:',err);
	}else{
		console.log('Connection established to', url);
	}

	var cursor = db.collection('cffplants').find();

	cursor.each(function(err,doc){
	console.log(doc);
	});
});
*/

var express = require('express');
var app = express()
var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost/test'
var str = "";

app route('/cffplants').get(function(req, res){

	MongoClient.connect(url,function(err,db){
		var cursor = db.collection('cffplants').find();

		cursor.each(function(err,item){
			if(item != null){
				str = str + " canonical Name "+ item.canonicalName + "</br>";
			}
		});
		res.send(str);
	});
});

var server = app.listen(3000, function(){});